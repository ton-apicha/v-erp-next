# Menu Structure - V-CORE ERP

> **Version:** 1.0.0  
> **Last Updated:** 2026-01-06  
> **Purpose:** โครงสร้างเมนูสำหรับ Navigation Design

---

## 1. Main Sidebar Navigation

```
┌─────────────────────────────────────────────────────────────┐
│  V-CORE ERP                                    [🌙] [TH ▼]  │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  👤 Admin Name                                               │
│  ⚙️ Super Admin                                              │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  📊 Dashboard                                                │
│                                                              │
│  ── OPERATION ──────────────────────────────                │
│  👷 Workers                                                  │
│     ├── Pipeline (Kanban)                                   │
│     ├── Directory                                           │
│     └── Documents                                           │
│                                                              │
│  🤝 Agents                                                   │
│     ├── Database                                            │
│     ├── Commissions                                         │
│     └── Materials                                           │
│                                                              │
│  🏭 Clients                                                  │
│     ├── Factories                                           │
│     ├── Orders                                              │
│     └── Payroll                                             │
│                                                              │
│  ── FINANCE ────────────────────────────────                │
│  💰 Financial Center                                         │
│     ├── Loan Portfolio                                      │
│     ├── Accounting                                          │
│     └── Remittance                                          │
│                                                              │
│  ── SERVICES ───────────────────────────────                │
│  🎓 Academy                                                  │
│     ├── Classes                                             │
│     ├── Assessments                                         │
│     └── Inventory                                           │
│                                                              │
│  💎 V-Care                                                   │
│     ├── Matching                                            │
│     └── Guarantees                                          │
│                                                              │
│  ── REPORTS ────────────────────────────────                │
│  📈 Analytics                                                │
│     ├── Dashboard                                           │
│     ├── Custom Reports                                      │
│     └── Export Center                                       │
│                                                              │
│  ── SYSTEM ─────────────────────────────────                │
│  ⚙️ Settings                                                 │
│     ├── Users & Roles                                       │
│     ├── Notifications                                       │
│     ├── Localization                                        │
│     ├── Audit Logs                                          │
│     └── System Monitor                                      │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│  [🔴 SOS Alerts: 2]                                         │
│  [🚪 Logout]                                                 │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Route Structure

```typescript
const routes = {
  // Dashboard
  dashboard: '/dashboard',
  
  // Workers
  workers: {
    pipeline: '/workers/pipeline',
    directory: '/workers',
    detail: '/workers/[id]',
    documents: '/workers/[id]/documents',
    create: '/workers/new',
  },
  
  // Agents
  agents: {
    list: '/agents',
    detail: '/agents/[id]',
    commissions: '/agents/commissions',
    materials: '/agents/materials',
    create: '/agents/new',
  },
  
  // Clients
  clients: {
    list: '/clients',
    detail: '/clients/[id]',
    orders: '/clients/orders',
    orderDetail: '/clients/orders/[id]',
    payroll: '/clients/payroll',
    create: '/clients/new',
  },
  
  // Finance
  finance: {
    loans: '/finance/loans',
    loanDetail: '/finance/loans/[id]',
    accounting: '/finance/accounting',
    remittance: '/finance/remittance',
  },
  
  // Academy
  academy: {
    classes: '/academy/classes',
    classDetail: '/academy/classes/[id]',
    assessments: '/academy/assessments',
    inventory: '/academy/inventory',
  },
  
  // V-Care
  vcare: {
    matching: '/vcare/matching',
    guarantees: '/vcare/guarantees',
  },
  
  // Reports
  reports: {
    dashboard: '/reports',
    custom: '/reports/custom',
    export: '/reports/export',
  },
  
  // Settings
  settings: {
    users: '/settings/users',
    notifications: '/settings/notifications',
    localization: '/settings/localization',
    auditLogs: '/settings/audit-logs',
    monitor: '/settings/monitor',
  },
  
  // Auth
  auth: {
    login: '/login',
    logout: '/logout',
  },
};
```

---

## 3. Permission Matrix

| Menu | Super Admin | Manager | Operation | Finance | Viewer |
|------|-------------|---------|-----------|---------|--------|
| Dashboard | ✅ | ✅ | ✅ | ✅ | ✅ |
| Workers | ✅ Full | ✅ Full | ✅ Full | 👁️ Read | 👁️ Read |
| Agents | ✅ Full | ✅ Full | ✅ Full | ❌ | ❌ |
| Clients | ✅ Full | ✅ Full | 👁️ Read | 👁️ Read | ❌ |
| Finance - Loans | ✅ Full | 👁️ Read | ❌ | ✅ Full | ❌ |
| Finance - Accounting | ✅ Full | 👁️ Read | ❌ | ✅ Full | ❌ |
| Finance - Remittance | ✅ Full | 👁️ Read | ❌ | ✅ Full | ❌ |
| Academy | ✅ Full | ✅ Full | ✅ Full | ❌ | ❌ |
| V-Care | ✅ Full | ✅ Full | ✅ Full | ❌ | ❌ |
| Reports | ✅ Full | ✅ Full | ✅ Limited | ✅ Financial | 👁️ Dashboard |
| Settings - Users | ✅ Full | ❌ | ❌ | ❌ | ❌ |
| Settings - Audit Logs | ✅ Full | 👁️ Read | ❌ | ❌ | ❌ |
| Settings - Monitor | ✅ Full | 👁️ Read | ❌ | ❌ | ❌ |

---

## 4. Top Navigation Bar

```
┌────────────────────────────────────────────────────────────────────────────┐
│  [☰]  V-CORE                    [🔍 Search...]              [🔔 3] [👤 ▼]  │
└────────────────────────────────────────────────────────────────────────────┘
```

### Components

| Element | Description |
|---------|-------------|
| ☰ | Toggle sidebar (collapse/expand) |
| V-CORE | Logo/Brand (click = go to dashboard) |
| 🔍 Search | Global search (workers, agents, clients) |
| 🔔 | Notifications bell with count |
| 👤 | User menu (Profile, Settings, Logout) |

### Global Search

```typescript
interface SearchResult {
  type: 'worker' | 'agent' | 'client' | 'order';
  id: string;
  title: string; // ชื่อ/รหัส
  subtitle: string; // สถานะ/ข้อมูลเพิ่มเติม
  url: string; // Link ไปหน้า detail
}

// ค้นหาได้ด้วย:
// - ชื่อ/นามสกุล (TH/EN/LA)
// - ชื่อเล่น
// - เบอร์โทร
// - เลขพาสปอร์ต
// - รหัส (Worker ID, Agent ID, Client ID)
// - ชื่อบริษัท/โรงงาน
```

---

## 5. Breadcrumb Trail

```
Dashboard / Workers / Somchai Samart (W-240101-0001)
```

### Pattern

```typescript
interface Breadcrumb {
  label: string;
  href: string;
  current?: boolean;
}

// Example for /workers/abc123
const breadcrumbs: Breadcrumb[] = [
  { label: 'Dashboard', href: '/dashboard' },
  { label: 'Workers', href: '/workers' },
  { label: 'Somchai Samart', href: '/workers/abc123', current: true },
];
```

---

## 6. Quick Actions (Floating Action Button)

```
       ┌─────────────────┐
       │ ➕ Quick Add    │
       ├─────────────────┤
       │ 👷 New Worker   │
       │ 🤝 New Agent    │
       │ 🏭 New Client   │
       │ 📄 New Order    │
       └─────────────────┘
```

### Visibility by Role

| Action | Super Admin | Manager | Operation | Finance |
|--------|-------------|---------|-----------|---------|
| New Worker | ✅ | ✅ | ✅ | ❌ |
| New Agent | ✅ | ✅ | ✅ | ❌ |
| New Client | ✅ | ✅ | ❌ | ❌ |
| New Order | ✅ | ✅ | ❌ | ❌ |

---

## 7. Dashboard Widgets Layout

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              DASHBOARD                                       │
├───────────────────────────────┬───────────────────────────────┬─────────────┤
│     TOTAL WORKERS             │     PIPELINE STATUS           │   TODAY     │
│     ┌───────────────────┐     │     ┌───────────────────┐     │  ┌───────┐  │
│     │    12,450         │     │     │ █████░░░░░ 60%    │     │  │ +15   │  │
│     │ Active: 10,200    │     │     │ Ready: 234        │     │  │ สมัคร  │  │
│     │ Inactive: 2,250   │     │     │ Deployed: 1,456   │     │  └───────┘  │
│     └───────────────────┘     │     └───────────────────┘     │  ┌───────┐  │
│                               │                               │  │ 8     │  │
│                               │                               │  │ ส่งตัว │  │
│                               │                               │  └───────┘  │
├───────────────────────────────┴───────────────────────────────┴─────────────┤
│                          ACTION REQUIRED                                     │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │ 🔴 URGENT: 5 visas expiring this week                     [View →]     │ │
│  │ 🟡 ALERT: Factory A overdue payroll file                  [View →]     │ │
│  │ 🟢 APPROVAL: 12 commission payments pending               [View →]     │ │
│  │ 🆘 SOS: 2 active alerts                                   [View →]     │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
├───────────────────────────────────────────────────────────────────────────┬─┤
│              MAP VISUALIZATION                                             │ │
│  ┌────────────────────────────────────────────────────────────────────┐   │ │
│  │                                                                    │   │ │
│  │                    [LAOS-THAILAND MAP]                            │   │ │
│  │                                                                    │   │ │
│  │   🔵 Sourcing Hotspots     🔴 Placement Locations                 │   │ │
│  │   🚌 Fleet Tracking        📍 SOS Locations                       │   │ │
│  │                                                                    │   │ │
│  └────────────────────────────────────────────────────────────────────┘   │ │
│                                                                            │ │
├────────────────────────────────────────────────────────────────────────────┤
│                       FINANCIAL SUMMARY                                     │
│  ┌──────────────────┬──────────────────┬──────────────────┬──────────────┐ │
│  │ Total Loans      │ Collection MTD   │ NPL Rate         │ Remittance   │ │
│  │ ฿ 45,230,000     │ ฿ 3,450,000      │ 2.3%             │ ฿ 1,200,000  │ │
│  │ ↑ 5% vs LM       │ ↑ 12% vs LM      │ ↓ 0.5% vs LM     │ ↑ 8% vs LM   │ │
│  └──────────────────┴──────────────────┴──────────────────┴──────────────┘ │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Mobile Responsive Behavior

### Breakpoints

| Breakpoint | Width | Layout |
|------------|-------|--------|
| Desktop | ≥1280px | Full sidebar + content |
| Tablet | 768-1279px | Collapsible sidebar |
| Mobile | <768px | Bottom navigation |

### Mobile Bottom Navigation

```
┌──────────┬──────────┬──────────┬──────────┬──────────┐
│    📊    │    👷    │    💰    │    🔔    │    ☰    │
│ Dashboard│ Workers  │ Finance  │ Alerts   │  More   │
└──────────┴──────────┴──────────┴──────────┴──────────┘
```

---

## 9. Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Cmd/Ctrl + K` | Open global search |
| `Cmd/Ctrl + N` | Quick add menu |
| `Cmd/Ctrl + /` | Toggle sidebar |
| `Esc` | Close modal/overlay |
| `G then D` | Go to Dashboard |
| `G then W` | Go to Workers |
| `G then A` | Go to Agents |
| `G then C` | Go to Clients |
| `G then F` | Go to Finance |
